#ifndef MAIN_HH
#define MAIN_HH

#include <iostream>
#include <vector>

using namespace std;

extern double p;
extern vector<vector<int>> graph; 

#endif