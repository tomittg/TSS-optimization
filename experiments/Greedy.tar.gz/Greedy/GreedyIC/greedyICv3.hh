#ifndef GREEDYICV3_HH
#define GREEDYICV3_HH

#include <iostream>
#include <set>

using namespace std;

set<int> greedv3();

#endif