#include <iostream>
#include <vector>
#include <set>
#include <queue>
#include <chrono>
#include <fstream>
#include <filesystem>
#include <chrono>
#include "main.hh"
#include "greedyIC.hh"
#include "greedyICv2.hh"
#include "greedyICv3.hh"
#include "difusioIC.hh"

using namespace std;
namespace fs = std::filesystem;

double p;
vector<vector<int>> graph;  // adjacency list of the graph

void Usage() {
    cout << "Usage: ./main p" << endl;
    exit(1);
}

void readFileGraph(string s);

void writeSetsOnFile(const set<int>& minimumS, string s);

void writePercentsActOnFile(string s, const vector<pair<int, double>>& percent);

void writeTimeOnFile(string s, double time);

int main(int argc, char* argv[]) {
    if (argc != 2) Usage();
    p = stod(argv[1]);
    fs::path directoryInstances = fs::current_path() / "instances"; //directory with graphs
    fs::path directoryTimesv1 = fs::current_path() / "greedyResultsIC/times/version1"; 
    fs::path directoryTimesv2 = fs::current_path() / "greedyResultsIC/times/version2";
    fs::path directoryTimesv3 = fs::current_path() / "greedyResultsIC/times/version3";
    fs::path directoryPercentv1 = fs::current_path() / "greedyResultsIC/percentOfActivation/version1";
    fs::path directoryPercentv2 = fs::current_path() / "greedyResultsIC/percentOfActivation/version2";
    fs::path directoryPercentv3 = fs::current_path() / "greedyResultsIC/percentOfActivation/version3";

    set<int> minimumS;
    int total;

    for (auto file : fs::directory_iterator(directoryInstances)) { //go through the file's
        if (!file.is_directory()) {

            string name = file.path().filename().string();
            readFileGraph(file.path().string());

            //Greedy version 1
       
            vector<pair<int, double>> percentActSet(10);
            double totalTime = 0;

            for(int i = 0; i < 10; ++i) {
                int totalSize = 0;

                auto start = chrono::high_resolution_clock::now();

                minimumS = greed();
                
                auto end = chrono::high_resolution_clock::now();
                auto time = chrono::duration_cast<chrono::microseconds>(end - start).count() / 1000000.0;
                totalTime += time;

                for(int j = 0; j < 100; ++j) {
                    totalSize += IC(minimumS);
                }
                double percentAct = ((totalSize/100.0)*100)/(graph.size()-1);
                percentActSet[i] = make_pair(minimumS.size(), percentAct);
                
            }
            writePercentsActOnFile(directoryPercentv1.string()+"/"+name+".out", percentActSet);
            writeTimeOnFile(directoryTimesv1.string()+"/"+name+".out", totalTime/10);

            //Greedy version 2
            totalTime = 0;
            
            for(int i = 0; i < 10; ++i) {
                int totalSize = 0;

                auto start = chrono::high_resolution_clock::now();

                minimumS = greed();
                
                auto end = chrono::high_resolution_clock::now();
                auto time = chrono::duration_cast<chrono::microseconds>(end - start).count() / 1000000.0;
                totalTime += time;

                for(int j = 0; j < 100; ++j) {
                    totalSize += IC(minimumS);
                }
                double percentAct = ((totalSize/100.0)*100)/(graph.size()-1);
                percentActSet[i] = make_pair(minimumS.size(), percentAct);
                
            }
            writePercentsActOnFile(directoryPercentv2.string()+"/"+name+".out", percentActSet);
            writeTimeOnFile(directoryTimesv2.string()+"/"+name+".out", totalTime/10);
            
            //Greedy version 3
            totalTime = 0;
            
            for(int i = 0; i < 10; ++i) {
                int totalSize = 0;

                auto start = chrono::high_resolution_clock::now();

                minimumS = greed();
                
                auto end = chrono::high_resolution_clock::now();
                auto time = chrono::duration_cast<chrono::microseconds>(end - start).count() / 1000000.0;
                totalTime += time;

                for(int j = 0; j < 100; ++j) {
                    totalSize += IC(minimumS);
                }
                double percentAct = ((totalSize/100.0)*100)/(graph.size()-1);
                percentActSet[i] = make_pair(minimumS.size(), percentAct);
                
            }
            writePercentsActOnFile(directoryPercentv3.string()+"/"+name+".out", percentActSet);
            writeTimeOnFile(directoryTimesv3.string()+"/"+name+".out", totalTime/10);
        }
    }
}

void readFileGraph(string s) {
    ifstream file(s);
    string line;
    int n, m;

    if(file.is_open())  {
        getline(file, line); //Reads the first line
        sscanf(line.c_str(), "p edge %d %d", &n, &m); 
        graph = vector<vector<int>> (n+1);
        for(int i = 0; i < m; ++i) {
            int u, v;
            getline(file, line);
            sscanf(line.c_str(), "e %d %d", &u, &v);
            graph[u].push_back(v);
            graph[v].push_back(u);
        }
        file.close();
    } else cout << "Error opening the file" << endl;
}

void writeSetsOnFile(const set<int>& minimumS, string s) {
    ofstream file(s);
    if(file.is_open()) {
        for(auto s : minimumS) file << s << " ";
        file << endl;
        file.close();
    }
}

void writePercentsActOnFile(string s, const vector<pair<int, double>>& percent) {
    ofstream file(s);
    if(file.is_open()) {
        for(auto p : percent) file << p.first << " " << p.second << endl; //GraphName SizeMinumumSet PercentOfActivation
        file.close();
    }
}

void writeTimeOnFile(string s, double time) {
    ofstream file(s);
    if(file.is_open()) {
        file << time << endl; //GraphName MedianOfAlgorithmTime
        file.close();
    }
}


