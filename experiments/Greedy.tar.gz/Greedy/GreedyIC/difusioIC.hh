#ifndef DIFUSIOIC_HH
#define DIFUSIOIC_HH

#include <iostream>
#include <set>

using namespace std;

int IC(set<int> minimumS);

#endif