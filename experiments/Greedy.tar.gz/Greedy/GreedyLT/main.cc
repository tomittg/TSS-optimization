#include <iostream>
#include <vector>
#include <set>
#include <queue>
#include <chrono>
#include <fstream>
#include <filesystem>
#include <chrono>
#include "main.hh"
#include "greedyLT.hh"
#include "greedyLTv2.hh"
#include "greedyLTv3.hh"
#include "difusioLT.hh"

using namespace std;
namespace fs = std::filesystem;

double r;
vector<vector<int>> graph;  // adjacency list of the graph

void Usage() {
    cout << "Usage: ./main p" << endl;
    exit(1);
}

void readFileGraph(string s);

void writeSetsOnFile(const set<int>& minimumS, double time, int size, string s);

int main(int argc, char* argv[]) {
    if (argc != 2) Usage();
    r = stod(argv[1]);
    fs::path directoryInstances = fs::current_path() / "instances"; //directory with graphs
    fs::path directoryGreedyLT = fs::current_path() / "greedyResultsLTv1"; //directory for greedyResultsLTv2
    fs::path directoryGreedyLT2 = fs::current_path() / "greedyResultsLTv2"; //directory for greedyResultsLTv2
    fs::path directoryGreedyLT3 = fs::current_path() / "greedyResultsLTv3"; //directory for greedyResultsLTv2
    set<int> minimumS;
    int total = 0;

    for (auto file : fs::directory_iterator(directoryInstances)) { //go through the file's
        if (!file.is_directory()) {
            string name = file.path().filename().string();

            //Greedy version 1
            
            readFileGraph(file.path().string());

            auto startg1 = chrono::high_resolution_clock::now();

            minimumS = greed();

            auto endg1 = chrono::high_resolution_clock::now();
            auto timeg1 = chrono::duration_cast<chrono::microseconds>(endg1 - startg1).count() / 1000000.0;

            writeSetsOnFile(minimumS, timeg1, minimumS.size(), directoryGreedyLT.string()+"/"+name+".out");

            //Greedy version 2
            auto startg2 = chrono::high_resolution_clock::now();

            minimumS = greedv2();

            auto endg2 = chrono::high_resolution_clock::now();
            auto timeg2 = chrono::duration_cast<chrono::microseconds>(endg2 - startg2).count() / 1000000.0;

            writeSetsOnFile(minimumS, timeg2, minimumS.size(), directoryGreedyLT2.string()+"/"+name+".out");
            
            //Greedy version 3
            auto startg3 = chrono::high_resolution_clock::now();

            minimumS = greedv3();

            auto endg3 = chrono::high_resolution_clock::now();
            auto timeg3 = chrono::duration_cast<chrono::microseconds>(endg3 - startg3).count() / 1000000.0;

            writeSetsOnFile(minimumS, timeg3, minimumS.size(), directoryGreedyLT3.string()+"/"+name+".out");
        }
    }
}

void readFileGraph(string s) {
    ifstream file(s);
    string line;
    int n, m;

    if(file.is_open())  {
        getline(file, line); //Reads the first line
        sscanf(line.c_str(), "p edge %d %d", &n, &m); 
        graph = vector<vector<int>> (n+1);
        for(int i = 0; i < m; ++i) {
            int u, v;
            getline(file, line);
            sscanf(line.c_str(), "e %d %d", &u, &v);
            graph[u].push_back(v);
            graph[v].push_back(u);
        }
        file.close();
    } else cout << "Error opening the file" << endl;
}

void writeSetsOnFile(const set<int>& minimumS, double time, int size, string s) {
    ofstream file(s);
    if(file.is_open()) {
        file << time << " " << size << endl;
        for(auto s : minimumS) file << s << endl;
        file.close();
    }
}

