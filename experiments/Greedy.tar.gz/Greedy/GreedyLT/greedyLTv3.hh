#ifndef GREEDYLTV3_HH
#define GREEDYLTV3_HH

#include <iostream>
#include <set>

using namespace std;

set<int> greedv3();

#endif