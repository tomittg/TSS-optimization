#ifndef GREEDYLT_HH
#define GREEDYLT_HH

#include <iostream>
#include <set>

using namespace std;

set<int> greed();

#endif