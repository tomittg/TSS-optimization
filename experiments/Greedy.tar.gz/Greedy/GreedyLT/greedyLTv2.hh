#ifndef GREEDYLTV2_HH
#define GREEDYLTV2_HH

#include <iostream>
#include <set>

using namespace std;

set<int> greedv2();

#endif