#ifndef DIFUSIOLT_HH
#define DIFUSIOLT_HH

#include <iostream>
#include <set>

using namespace std;

int LT(set<int> minimumS);

#endif