#include <iostream>
#include <vector>
#include <queue>
#include <set>
#include "main.hh"
#include "greedyLTv3.hh"

using namespace std;

extern double r;
extern vector<vector<int>> graph; // adjacency list of the graph
vector<bool> activatedNodesv3;      // list of nodes that have been activated
int sumActivatedNodesv3;            // sum of activated nodes

struct comparePairs
{
   bool operator()(const pair<int, int> &p1, const pair<int, int> &p2)
   {
      return p1.second < p2.second;
   }
};

void LTDiffusionv3(int node, priority_queue<pair<int, int>, vector<pair<int, int>>, comparePairs> &candidateNodes, vector<int> &currentDegree)
{
   queue<int> activationQueue;
   activationQueue.push(node);
   activatedNodesv3[node] = true;
   sumActivatedNodesv3++;
   for (int neighbourNode : graph[node])
   {
      currentDegree[neighbourNode]--;
   }

   while (!activationQueue.empty()) 
   {
        int currentNode = activationQueue.front();
        activationQueue.pop();

        for (int adjacentNode : graph[currentNode])
        {
            if (!activatedNodesv3[adjacentNode] and (graph[adjacentNode].size() - currentDegree[adjacentNode] >= r * graph[adjacentNode].size()))
            {
                activationQueue.push(adjacentNode);
                activatedNodesv3[adjacentNode] = true;
                sumActivatedNodesv3++;
                for (int neighbourNode : graph[adjacentNode])
                {
                    if(!activatedNodesv3[neighbourNode]){
                        currentDegree[neighbourNode]--;
                    }
                }
            }
        }
    }
}

set<int> greedv3()
{
   priority_queue<pair<int, int>, vector<pair<int, int>>, comparePairs> candidateNodes;
   activatedNodesv3 = vector<bool> (graph.size(), false);
   sumActivatedNodesv3 = 0;
   vector<int> currentDegree(graph.size(), 0);
   set<int> S;

   for (int i = 1; i < graph.size(); ++i)
   {
      int iDegree = graph[i].size();
      candidateNodes.push({i, iDegree});
      currentDegree[i] = iDegree;
   }

   while (sumActivatedNodesv3 < graph.size() - 1)
   {
      int node = candidateNodes.top().first;
      candidateNodes.pop();
    
      if (not activatedNodesv3[node])
      {
         LTDiffusionv3(node, candidateNodes, currentDegree);
         S.insert(node);
      }
   }
   return S;
}
